# ТЗ: КАУЗАЛЬНАЯ ПАМЯТЬ, СОЦИАЛЬНОЕ ПОНИМАНИЕ И ФОРМИРОВАНИЕ ЛИЧНОСТИ NPC

**Проект:** ENIGMA Engine

**Подсистема:** Memory / Cognition / Social Modeling

**Версия документа:** 3.0

**Статус:** Архитектурная спецификация с актуализацией состояния.

**Текущее состояние проекта:** Этапы 0-4 частично реализованы. RCE-слой создан (S86). STM-контур замкнут. Перед любыми изменениями обязательна археология.

**Последняя актуализация:** Сессия 86 (RCE + STM fix)

---

# 0.5. ИСПРАВЛЕННЫЕ КРИТИЧЕСКИЕ БАГИ (S86)

Три бага блокировали работу памяти. Все исправлены.

## Баг 1: run_turn не возвращал результат

- **Файл:** `backend/app/services/game_loop/__init__.py:648`
- **Суть:** Метод `run_turn()` создавал `_final_response`, но не возвращал его. Функция завершалась неявно, возвращая `None`, что крашило `routes.py` при доступе к `result.dm_response`.
- **Фикс:** Добавлен `return _final_response`

## Баг 2: json.loads возвращал строку

- **Файл:** `backend/app/agents/dm_agent.py:673`
- **Суть:** LLM иногда возвращал JSON-строку (`"некий текст"`). `json.loads()` парсил её в `str`, затем `result.get("dm_response")` крашился с `AttributeError: 'str' object has no attribute 'get'`.
- **Фикс:** Добавлена проверка `isinstance(result, dict)` после `json.loads()`

## Баг 3: @property внутри __init__

- **Файл:** `backend/app/services/game_loop/__init__.py:125`
- **Суть:** `@property saves_dir` был вставлен прямо внутрь `__init__`. Весь код после `return self._saves_dir` (строки 129+) стал мёртвым — `self.memory_manager`, `self._session_started_campaigns` и остальные атрибуты **никогда не инициализировались**.
- **Фикс:** Property перенесён после `__init__`
- **Следствие:** Этот баг существовал с момента добавления property. Без его исправления половина GameLoop работала на `AttributeError` → `getattr` fallback.

**Философия:**

NPC должны не просто хранить факты.

NPC должны:

* помнить;
* интерпретировать;
* обобщать;
* строить гипотезы;
* прогнозировать;
* менять поведение под воздействием опыта.

Конечной целью является появление причинно-следственной социальной среды, а не системы хранения событий.

---

# 1. ОБЩАЯ ЦЕПОЧКА КОГНИТИВНОЙ ЭВОЛЮЦИИ

Каждый слой должен порождать следующий.

```text
Event
    ↓
EventMemory
    ↓
Recall
    ↓
ExperiencePattern
    ↓
CausalBelief
    ↓
IdentityTrait
    ↓
CulturalKnowledge
    ↓
Decision
    ↓
New Event
```

Любой новый слой обязан отвечать на вопрос:

"Каким образом он меняет поведение NPC?"

Если слой не влияет на поведение, он считается архитектурным шумом.

---

# 2. ОБЯЗАТЕЛЬНОЕ ПРАВИЛО АРХЕОЛОГИИ

Перед началом любого этапа запрещено реализовывать код.

Необходимо:

1. Найти все существующие реализации.
2. Найти все фактические точки вызова.
3. Найти все обходные пути.
4. Найти весь legacy-код.
5. Составить карту данных.
6. Составить карту потока информации.
7. Зафиксировать расхождение между ТЗ и фактическим состоянием.

Только после этого разрешено проектирование изменений.

---

# ЭТАП 0. ЕДИНЫЙ ЯЗЫК СОБЫТИЙ

## Статус

⚠️ ЧАСТИЧНО РЕАЛИЗОВАНО. Требуется доревизия.

---

## Археологическая карта (S86)

| Компонент | Файл | Статус |
|-----------|------|--------|
| EventDTO | `backend/app/models/events/event_dto.py` | ✅ Существует, frozen dataclass |
| EventBus | `backend/app/services/events/event_bus.py` | ✅ Существует, синхронный |
| EventType | `backend/app/models/events/event_type.py` | ✅ Enum с типами |
| NPC_SPOKE publish | `backend/app/services/memory/working_memory_tick.py:62` | ✅ RCE пишет через EventBus |
| Player action publish | `backend/app/services/game_loop/dm_phase.py:130` | ✅ emit_and_accumulate_scene_events |

### Известные обходные пути

1. **RCE → write_npc_reactions_to_memory** — пишет в STM через `memory_manager.add_dialogue_turn()`, минуя EventBus для STM-слоя. Но также публикует `NPC_SPOKE` в EventBus.
2. **dm_phase.py:117** — `add_dialogue_turn(speaker="player")` — прямой вызов, не через EventBus.
3. **NarrativeExtractor** (`r2.1`) — извлекает объекты/события из DM-текста, но не публикует их как EventDTO.

### Расхождение с ТЗ

- Не все события мира проходят через EventBus
- STM-запись идёт напрямую в MemoryManager, а не через EventBus → MemoryManager
- NarrativeExtractor не генерирует EventDTO

---

## Требуемое состояние

Все события мира представлены EventDTO.

Существует единственная точка публикации событий.

---

## Проверка

Составить полный граф:

```text
Источник
    ↓
EventDTO
    ↓
EventBus
    ↓
Подписчики
```

---

# ЭТАП 1. STM — КРАТКОВРЕМЕННАЯ ПАМЯТЬ

## Статус

✅ РЕАЛИЗОВАНО. Контур замкнут (S86).

---

## Археологическая карта (S86)

| Компонент | Файл | Назначение |
|-----------|------|------------|
| DialogueSession | `backend/app/services/memory/memory_manager.py:50` | per-NPC буфер, ключ `campaign_id:npc_id` |
| add_dialogue_turn() | `memory_manager.py:67` | Добавляет реплику в STM (speaker + text) |
| get_recent_speech_all_npcs() | `memory_manager.py:273` | Читает все реплики кампании для DM |
| clear_all_dialogue_sessions() | `memory_manager.py:79` | Уничтожает STM при move/stealth |
| RCE → STM write | `working_memory_tick.py:76` | Речь NPC → STM через write_npc_reactions_to_memory |
| Player speech → STM | `dm_phase.py:117` | Речь игрока → STM при dialogue/player_interacts |
| STM → DM prompt | `dm_agent.py:196` | npc_recent_speech инжектится в промпт как "Краткая память" |

### Замкнутый контур (подтверждён S86)

```text
DM генерирует текст с речью NPC
    ↓
RCE (rce.py) извлекает речь из кавычек или fallback
    ↓
write_npc_reactions_to_memory() → add_dialogue_turn()
    ↓
dm_phase.py:117 → add_dialogue_turn(speaker="player")
    ↓
get_recent_speech_all_npcs() читает все сессии
    ↓
dm_phase.py:81 → shared_context.npc_recent_speech
    ↓
dm_agent.py:199 → builder.add_npc_stm() → промпт DM
    ↓
DM видит прошлый разговор → NPC помнит
```

### Новые компоненты (созданы S86)

| Компонент | Файл | Назначение |
|-----------|------|------------|
| **RCE** (Reality Commit Extractor) | `backend/app/services/memory/rce.py` | Детерминированный экстрактор речи из DM-нарратива |
| Quote normalization | `rce.py:_normalize_quotes()` | Unicode `""` → ASCII `"` для единого парсинга |
| Speaker binding | `rce.py:_resolve_speaker()` | Имя в контексте → target fallback → no-quotes fallback |
| List support in STM writer | `working_memory_tick.py:50-58` | `all_npcs_raw` может быть list или dict |

### Архитектурный инвариант (S86)

> **Ни один LLM-выход не считается состоянием мира, пока не прошёл RCE-коммит.**

### Известные ограничения

1. **RCE fallback (без кавычек):** когда DM "забывает" кавычки, весь текст приписывается target NPC. Это может быть неточно в multi-NPC сценах. Решение — RCE v2.0 с confidence-скорингом.
2. **clear_all_dialogue_sessions при "move":** dm_phase.py:124 уничтожает всю память при действии "move". IntentCompressor может переопределять `player_interacts` → `move`, что убивает STM. Требуется аудит ADR-091.
3. **STM не различает "сказано" и "принято как истина":** NPC помнит что игрок сказал "1+1=3", но не верит этому. Это правильное поведение, но требует явной онтологии в будущих этапах.
4. **Счётчик реплик ограничен:** `get_recent_speech_all_npcs(limit=5)` — только 5 последних реплик.

---

## Требуемое состояние

STM хранит только текущий разговор.

STM уничтожается после завершения сцены.

---

## Поведенческий результат

NPC способен ссылаться на реплики текущего разговора. ✅ Подтверждено S86.

---

# ЭТАП 2. ЕДИНАЯ ДОЛГОВРЕМЕННАЯ ПАМЯТЬ

## Статус

⚠️ ЧАСТИЧНО РЕАЛИЗОВАНО. Требуется доревизия.

---

## Археологическая карта (S86)

| Компонент | Файл | Назначение |
|-----------|------|------------|
| MemoryManager.apply() | `memory_manager.py` | Основной канал записи воспоминаний |
| LayeredMemory | `memory_manager.py` | STM → L2 (narr_cache) → Campaign |
| PromotionEngine | `memory_manager.py` | Продвижение session → campaign |
| NarrativeCache (L2) | `npc_state.py:narrative_cache` | Tuple[EventMemory] — per-NPC |
| SQLite persistence | `persistence/sqlite_adapter.py` | Runtime truth для NPC state |
| JSON persistence | `persistence/json_adapter.py` | Legacy fallback |
| persist_dm_response() | `game_loop/__init__.py:640` | Запись DM-ответа в память |

### Поток данных (подтверждён)

```text
EventDTO (NPC_SPOKE / player action)
    ↓
MemoryManager.apply(event, npc_state)
    ↓
LayeredMemory: STM write → L2 narrative_cache update
    ↓
PromotionEngine: importance > threshold → Campaign memory (SQLite)
    ↓
SQLite atomic commit
```

### Известные обходные пути

1. **RCE → write_npc_reactions_to_memory** — пишет в STM через `add_dialogue_turn()`, но NOT через `MemoryManager.apply()`. Нарушает единый канал.
2. **dm_phase.py:117** — `add_dialogue_turn(speaker="player")` — тоже минует `apply()`.
3. **NarrativeExtractor** (`game_loop/__init__.py:586`) — применяет извлечения напрямую к scene_state, не через MemoryManager.

### Расхождение с ТЗ

- STM-запись идёт через `add_dialogue_turn()`, а не через `MemoryManager.apply()`
- Два параллельных канала записи: `apply()` для EventDTO, `add_dialogue_turn()` для STM
- Нет единой точки создания воспоминания — есть две

---

## Требуемое состояние

Существует единственная точка создания долговременного воспоминания.

---

## Поведенческий результат

NPC способен помнить события между игровыми сессиями.

---

# ЭТАП 3. RECALL

## Статус

⚠️ ЧАСТИЧНО РЕАЛИЗОВАНО. Требуется доревизия.

---

## Археологическая карта (S86)

| Компонент | Файл | Назначение |
|-----------|------|------------|
| TopicExtractor | `backend/app/services/npc/topic_extractor.py` | Извлекает тему из STM + L2 для DecisionHub |
| get_recent_speech_all_npcs() | `memory_manager.py:273` | Чтение STM (все NPC, limit=5) |
| narrative_cache (L2) | `npc_state.py` | Tuple[EventMemory] — per-NPC долговременная |
| recalled_facts | `r3_direct_builder.py:231-238` | Извлечение из npc_contexts для DM промпта |
| get_stm_prompt_block() | `memory_manager.py:85` | Текстуализация STM для промпта |
| DialogueSession.buffer | `memory_manager.py` | Список реплик в текущем диалоге |

### Поток Recall (подтверждён S86)

```text
1. STM Recall (краткосрочный):
   get_recent_speech_all_npcs(limit=5)
       ↓
   shared_context.npc_recent_speech
       ↓
   dm_agent.py:196 → builder.add_npc_stm()
       ↓
   DM видит "Краткая память — текущий разговор"

2. L2 Recall (долгосрочный):
   npc_contexts[].verbalization_ctx.recalled_facts
       ↓
   r3_direct_builder.py:231 → shared_context.npc_recalled_memory
       ↓
   dm_agent.py:201 → builder.add_npc_stm() с importance > 0.7
       ↓
   DM видит "хорошо помнит / смутно помнит"
```

### Реализованные типы Recall

| Тип | Статус | Механизм |
|-----|--------|----------|
| Контекстное вспоминание | ✅ Работает | `npc_recent_speech` + `recalled_facts` в DM промпт |
| Триггерное вспоминание | ⚠️ Частично | `TopicExtractor` извлекает тему, но не триггерит Recall по событиям |
| Случайное вспоминание | ❌ Отсутствует | Нет механизма спонтанного Recall |

### Неотражённый компонент (обнаружен S86)

| Компонент | Файл | Назначение |
|-----------|------|------------|
| EventSemanticTagger | `memory/event_semantic_tagger.py` | Присваивает семантические теги событиям для поиска/извлечения памяти. Используется LayeredMemory для индексации при записи. |

EventSemanticTagger — ключевое звено для Recall: теги определяют, какие события будут найдены при recall по теме. Без тегов Recall работает только по recency (последние N), не по релевантности.

### Расхождение с ТЗ

- Recall привязан к DM-промпту, а не к NPC-решениям
- TopicExtractor извлекает тему для DecisionHub, но не инициирует Recall воспоминаний
- Нет случайного (spontaneous) Recall — NPC не "вспоминает" без внешнего триггера
- importance-фильтр захардкожен (>0.7 для "хорошо помнит") — не персонализирован

---

## Требуемое состояние

Recall обязан поддерживать:

* случайное вспоминание;
* триггерное вспоминание;
* контекстное вспоминание.

---

## Поведенческий результат

NPC вспоминает релевантные события. ⚠️ Только контекстное вспоминание работает.

---

# ЭТАП 4. ПАМЯТЬ В ВЕРБАЛИЗАЦИИ

## Статус

✅ РЕАЛИЗОВАНО. Путь памяти до LLM работает (S86).

---

## Археологическая карта (S86)

| Компонент | Файл | Назначение |
|-----------|------|------------|
| VerbalizationContext | `backend/app/services/verbalization/` | Контекст для сборки промпта NPC |
| DMContractBuilder | `backend/app/agents/dm_agent.py:140+` | Собирает system + user промпт |
| builder.add_npc_stm() | `dm_agent.py:199` | Инжектит STM в промпт |
| builder.add_custom_block() | `dm_agent.py:180-189` | Инжектит recalled_facts |
| shared_context.npc_recent_speech | `pipeline_context.py:66` | STM-данные для DM |
| shared_context.npc_recalled_memory | `r3_direct_builder.py:239` | L2-факты для DM |

### Полный маршрут (подтверждён S86)

```text
1. STM путь:
   get_recent_speech_all_npcs()
       ↓
   dm_phase.py:81 → shared_context.npc_recent_speech
       ↓
   dm_agent.py:196 → (context or {}).get("npc_recent_speech")
       ↓
   dm_agent.py:199 → builder.add_npc_stm()
       ↓
   DMContract.user_prompt → блок "Краткая память — текущий разговор"

2. L2 путь:
   npc_contexts[].verbalization_ctx.recalled_facts
       ↓
   r3_direct_builder.py:231-238 → shared_context.npc_recalled_memory
       ↓
   dm_agent.py:202 → (context or {}).get("npc_recalled_memory")
       ↓
   dm_agent.py:204-210 → builder с importance-фильтром
       ↓
   DMContract.user_prompt → блок "хорошо помнит / смутно помнит"

3. Сборка контракта:
   DMContractBuilder.build()
       ↓
   DMContract (system_prompt + user_prompt)
       ↓
   LLM (llama-server :8080)
       ↓
   RCE извлекает речь → STM-коммит для следующего тика
```

### Поведенческий результат (подтверждён S86)

- NPC ссылается на прошлые реплики в текущем разговоре ✅
- NPC помнит факты из L2 (importance > 0.7) ✅
- Контур DM → RCE → STM → DM замкнут ✅

### Известные ограничения

1. **STM и L2 идут в один промпт** — нет разделения "я помню это из разговора" vs "я знаю это из опыта"
2. **Importance-фильтр захардкожен** — 0.7 для "хорошо помнит", без персонализации
3. **NPC не инициирует Recall сам** — память подгружается только когда DM формирует промпт

---

## Требуемое состояние

Любое найденное воспоминание может попасть в речь NPC. ✅ Работает.

---

## Поведенческий результат

NPC упоминает прошлое. ✅ Подтверждено S86.

---

# ЭТАП 5. СЕКРЕТЫ И ДАВЛЕНИЕ

## Статус

⚠️ ЧАСТИЧНО РЕАЛИЗОВАНО. Требуется доревизия.

---

## Археологическая карта (S86)

| Компонент | Файл | Назначение |
|-----------|------|------------|
| is_secret | `EventMemory.is_secret` | Флаг секретности воспоминания |
| hidden_from | `EventMemory.hidden_from` | Список ID, от которых скрыто |
| get_suppressed_secrets() | `memory_manager.py:292` | Возвращает секреты, скрытые от target_id |
| suppressed_for_dm | `r3_direct_builder.py:240+` | Передаёт suppressed secrets в DM промпт |
| DialogueSession.get_pressure() | `memory_manager.py:286` | Давление по теме диалога |
| clear_dialogue_session() | `memory_manager.py:72` | Очистка сессии при завершении диалога |

### Поток данных (подтверждён)

```text
EventMemory(is_secret=True, hidden_from=['player'])
    ↓
get_suppressed_secrets(campaign_id, npc_id, hidden_from_id='player')
    ↓
r3_direct_builder.py → shared_context.suppressed_secrets
    ↓
dm_agent.py → инжект в промпт как "NPC знает, но скрывает"
    ↓
DM решает — проговориться или нет
```

### Реализованные механизмы

| Механизм | Статус | Примечание |
|----------|--------|------------|
| Помнить секрет | ✅ | `is_secret` + `hidden_from` |
| Не говорить | ⚠️ Частично | DM получает контекст, но может проигнорировать |
| Проговориться | ⚠️ Нет явного механизма | Нет `discovery_check` — решение за LLM |
| Сознательно скрывать | ❌ | Нет давления (pressure) → скрывать под стрессом |

### Расхождение с ТЗ

- Нет `discovery_check` — решает LLM, а не детерминированный механизм
- Нет связи `pressure` → вероятность проговорки — DialogueSession.get_pressure() считает давление по теме, но не влияет на раскрытие секретов
- Suppressed secrets передаются в DM, но нет явного запрета LLM их раскрывать
- Нет стресс-модификатора: пьяный NPC не проговаривается чаще трезвого

---

## Требуемое состояние

NPC может:

* помнить; ✅
* не говорить; ⚠️ Частично — зависит от LLM
* проговориться; ❌ Нет детерминированного механизма
* сознательно скрывать. ❌ Нет pressure → раскрытие

---

## Поведенческий результат

Игрок сталкивается с сопротивлением раскрытию информации. ⚠️ Случайно, не детерминировано.

---

# ЭТАП 6. КОНТРАКТЫ И ОБЯЗАТЕЛЬСТВА (Noblesse oblige)
Главный модуль: backend/app/services/social/noblesse_oblige.py
Понятие: Noblesse oblige — "положение обязывает". Обязательства возникают из социальной позиции и обещаний. Нарушение обязательства — не просто забытый факт, а событие, деформирующее социальный ландшафт.

## Статус

❌ НЕ РЕАЛИЗОВАНО. Археология не проводилась.

---

## Археологическая карта (S86)

| Компонент | Поиск | Результат |
|-----------|-------|-----------|
| promise_given | `Select-String -Pattern "promise"` | Не найдено |
| promise_received | `Select-String -Pattern "promise"` | Не найдено |
| debt | `Select-String -Pattern "debt"` | Только `economic_stress` в NeedEngine |
| get_unfulfilled_contracts() | `Select-String -Pattern "contract"` | Только DMContract (LLM промпт), не социальные контракты |

### Известные смежные механизмы

1. **NeedEngine + StressCalculator** — экономический стресс (долги как source of stress), но не социальные обязательства
2. **DecisionHub** — может учитывать `economic_stress` в решениях, но нет понятия "обещание"
3. **EventMemory** — может хранить событие "NPC обещал", но нет автоматического извлечения и влияния на поведение

### Расхождение с ТЗ

- Нет сущности "обязательство" (Contract / Promise) — будущий модуль: noblesse_oblige.py
- Нет связи "обещание" → "ожидание" → "разочарование" → "влияние на доверие"
- DecisionHub не имеет входа для невыполненных обязательств
- Память хранит факты, но не извлекает из них обязательства автоматически

---

## Требуемое состояние

Обязательства должны участвовать в принятии решений.

---

## Поведенческий результат

NPC требует исполнения обещаний. ❌ Не реализовано.

---

# ЭТАП 7. СОЦИАЛЬНАЯ ПАМЯТЬ NPC

## Статус

⚠️ ЧАСТИЧНО РЕАЛИЗОВАНО. Числовые отношения существуют, событийные — нет.

---

## Археологическая карта (S86)

| Компонент | Файл | Назначение |
|-----------|------|------------|
| RelationshipStore | `backend/app/services/social/relationship_store.py` | Хранит trust/fear (0-100) per NPC pair |
| relationship_cache | `NPCState` (в памяти) | Кэш отношений для DecisionHub |
| _get_rel_value() | `decision_hub.py` | Читает trust/fear из relationship_cache |
| _context_relevance() | `decision_hub.py` | Модулирует решение на основе отношений |
| SocialDecayHandler | `social/social_decay_handler.py` | Дрейф trust → base_value со временем |
| DirectiveInterpretationSubscriber | `events/directive_interpretation_subscriber.py` | Реакция на социальные директивы (obedience/irritation) |

### Реализованные механизмы

| Механизм | Статус | Примечание |
|----------|--------|------------|
| Числовые отношения (trust/fear) | ✅ | 0-100, per NPC pair |
| Влияние на DecisionHub | ✅ | `_get_rel_value()` + `_context_relevance()` |
| Decay отношений | ✅ | SocialDecayHandler — дрейф к базовому значению |
| Событийная память о взаимодействии | ❌ | Нет связи EventMemory → RelationshipStore |
| NPC-NPC отношения | ⚠️ Частично | DirectiveInterpretationSubscriber обрабатывает NPC→NPC директивы |

### Неотражённый компонент (обнаружен S86)

| Компонент | Файл | Назначение |
|-----------|------|------------|
| ResonanceEngine | `memory/resonance_engine.py` | Аффективный резонанс — искажение давления через аффективные imprint'ы. Когда NPC испытывает эмоцию, ResonanceEngine сканирует прошлые imprint'ы и усиливает/ослабляет текущее давление. Интегрирован в WillpowerGate. |

ResonanceEngine — мост между памятью и волей: прошлый аффективный опыт искажает текущие решения. Это зачаток "память влияет на поведение", но работает на уровне сырых сигналов, не на уровне социальных событий.

---

### Расхождение с ТЗ

- Отношения основаны на **числах** (trust: 0-100, fear: 0-100), а не на **событиях**
- Нет `recall(target_npc_id)` — нельзя извлечь "что Горан помнит о Венусе"
- Нет `npc_npc_context` — NPC не помнит историю взаимодействия с конкретным NPC
- Изменения trust/fear происходят через DirectiveInterpretationSubscriber, но не через накопление опыта
- RelationshipStore — SSOT (ADR-121), но не связан с EventMemory

---

## Требуемое состояние

Отношения основаны на событиях.

Не на числах.

---

## Поведенческий результат

NPC реагирует на историю взаимодействия. ⚠️ Реагирует на числа, не на историю.

---

# ЭТАП 8. ВРЕМЕННОЕ ЗАТУХАНИЕ

## Статус

⚠️ ЧАСТИЧНО РЕАЛИЗОВАНО. Decay существует, но привязка к игровому времени частичная.

---

## Археологическая карта (S86)

| Компонент | Файл | Назначение |
|-----------|------|------------|
| EventMemory.decayed() | `npc_state.py` | Экспоненциальное затухание importance по game_days |
| SocialDecayHandler | `social/social_decay_handler.py` | Дрейф trust/fear → base_value |
| AffectiveDecayHandler | `affective/affective_decay_handler.py` | Затухание affective_load (leaky integrator) |
| PhysiologyDecayHandler | `combat/physiology_decay_handler.py` | Затухание pain/fatigue/blood_loss/shock |
| TemporalEngine | `world/temporal_engine.py` | Игровой календарь и тик-счётчик |
| mark_decay_executed() | `temporal_engine.py` | Предотвращает двойной decay |
| NarrativeCache decay при загрузке | `memory_manager.py:260` | `_mem.decayed(game_days=1.0)` при каждом чтении |

### Реализованные механизмы

| Механизм | Статус | Привязка к времени |
|----------|--------|-------------------|
| Важность воспоминаний → decay | ✅ | `decayed(game_days=1.0)` — но захардкожено 1.0 день |
| Trust/fear → decay | ✅ | SocialDecayHandler — per tick, не per game_day |
| Affective load → decay | ✅ | AffectiveDecayHandler — per tick |
| Physiological decay | ✅ | per tick, экспоненциальный |
| STM → timeout | ❌ | STM очищается только при move/stealth, не по таймауту |

### Расхождение с ТЗ

- `decayed(game_days=1.0)` — захардкоженное значение, не реальное игровое время
- SocialDecayHandler работает per tick, не per game_day — скорость затухания зависит от FPS, не от календаря
- Нет CalendarService, интегрированного с MemoryManager
- STM не имеет временного затухания — очищается только при смене локации
- NarrativeCache применяет decay при каждой загрузке, а не по расписанию

---

## Требуемое состояние

Память стареет по игровому календарю.

---

## Поведенческий результат

Давние события вспоминаются хуже. ⚠️ Decay есть, но не привязан к реальному игровому времени.

---

# ЭТАП 9. MEMORY PROMOTION

## Статус

❌ НЕ РЕАЛИЗОВАНО. Спецификация готова, реализации нет.

---

## Цель

Преобразовывать множество событий в опыт.

---

## Философия

Сжатие не является целью.

Цель — извлечение закономерностей.

---

## Новая сущность

ExperiencePattern

```python
@dataclass
class ExperiencePattern:
    pattern_id: str
    pattern_type: str

    confidence: float

    evidence_events: list[str]

    created_day: int
    updated_day: int
```

---

## Примеры

```text
player_helped
player_helped
player_helped
```

↓

```text
PlayerFrequentlyHelpful
```

---

```text
tavernkeeper_hit
tavernkeeper_threatened
tavernkeeper_humiliated
```

↓

```text
TavernkeeperHostile
```

---

## Архитектурные требования

Создать:

MemoryPromotionEngine

---

Должны появиться:

* агрегация событий;
* извлечение повторяющихся паттернов;
* паттерн-ориентированный recall;
* интеграция в DecisionHub.

---

## Поведенческий результат

NPC начинает реагировать на историю взаимодействия, а не на отдельные события.

---

# ЭТАП 10. CAUSAL BELIEFS

## Статус

⚠️ ЧАСТИЧНО РЕАЛИЗОВАНО. Каркас есть, интеграции нет.

---

## Археологическая карта (S86)

| Компонент | Файл | Назначение | Статус |
|-----------|------|------------|--------|
| BeliefAggregator | `memory/belief_aggregator.py` | Агрегация свидетельств → убеждения | ⚠️ Существует, не подключён к пайплайну |
| ContradictionResolver | `memory/contradiction_resolver.py` | Разрешение противоречий в убеждениях | ⚠️ Существует, не подключён к пайплайну |
| EvidenceMapper | `memory/evidence_mapper.py` | Маппинг событий → свидетельства для BeliefAggregator | ⚠️ Существует, не подключён к пайплайну |

### Расхождение с ТЗ

- Компоненты существуют, но НЕ интегрированы в TickOrchestrator или MemoryManager
- Нет автоматического вызова: EventMemory → EvidenceMapper → BeliefAggregator → CausalBelief
- CausalBelief сущность не определена в коде (только в ТЗ)
- ContradictionResolver не вызывается при конфликте убеждений

---

## Статус (исходный)

❌ НЕ РЕАЛИЗОВАНО. Спецификация готова, реализации нет.

---

## Цель

Создать систему личных причинных гипотез NPC.

---

## ВАЖНО

Это не объективная истина.

Это субъективная модель мира конкретного NPC.

Разные NPC могут иметь противоположные убеждения.

---

## Предпосылки из реализованного (S86)

RCE уже создаёт базовый поток событий, из которого могут формироваться убеждения:

```text
DM генерирует нарратив
    ↓
RCE извлекает речь NPC → STM
    ↓
STM → Promotion → L2 narrative_cache
    ↓
L2 Events → [БУДУЩЕЕ] CausalLearningEngine анализирует причинные цепочки
```

Но сейчас события хранятся как факты без причинной связи. Нет извлечения "X привело к Y".

---

## Новая сущность

```python
@dataclass
class CausalBelief:
    belief_id: str

    cause: str
    effect: str

    confidence: float

    evidence_events: list[str]

    source: str
```

---

## Примеры

```text
долги
↓
разорение
```

---

```text
алкоголь
↓
насилие
```

---

```text
война
↓
голод
```

---

## Новый компонент

CausalLearningEngine

---

## Задачи

* обнаружение повторяющихся причинных цепочек;
* формирование гипотез;
* обновление уверенности;
* использование в Recall;
* использование в DecisionHub.

---

## Поведенческий результат

NPC начинает прогнозировать будущее.

---

# ЭТАП 11. IDENTITY EMERGENCE

## Статус

❌ НЕ РЕАЛИЗОВАНО. Спецификация готова, реализации нет.

---

## Цель

Создать личность как следствие опыта.

---

## ВАЖНО

Черты не задаются вручную.

Черты появляются из истории жизни.

---

## Предпосылки из реализованного (S86)

Сейчас NPC имеет "личность" через захардкоженные параметры:

| Параметр | Источник | Настраиваемость |
|----------|----------|----------------|
| drives_base (fear, control, significance) | NPC config YAML | ✅ Ручная настройка |
| willpower | NPC config YAML | ✅ Ручная настройка |
| trauma_markers | Пустой при старте | ⚠️ Не заполняется из опыта |
| affective_load | Вычисляется из PerceptualKernel | ✅ Динамический |

Проблема: drives_base и willpower — **константы**, не меняющиеся от опыта. NPC с одинаковой конфигурацией всегда реагируют одинаково, независимо от прожитого.

Identity Emergence должен превратить:
```text
Конфиг (статический) + Опыт (накапливаемый)
    ↓
Личность (динамическая)
```

---

## Новая сущность

```python
@dataclass
class IdentityTrait:
    trait_id: str

    strength: float

    source_patterns: list[str]

    source_beliefs: list[str]
```

---

## Примеры

```text
Многократное предательство
↓
DistrustsStrangers
```

---

```text
Частая помощь окружающих
↓
Optimistic
```

---

```text
Пережитая война
↓
AvoidsViolence
```

---

## Новый компонент

IdentityFormationEngine

---

## Задачи

* агрегация ExperiencePattern + CausalBelief → IdentityTrait;
* модификация drives_base через IdentityTrait;
* инъекция IdentityTrait в DecisionHub как контекст;
* инъекция IdentityTrait в вербализацию (речь отражает характер).

---

## Поведенческий результат

Два NPC с разной биографией начинают принимать разные решения в одинаковой ситуации.

---

# ЭТАП 12. CULTURAL KNOWLEDGE

## Статус

❌ НЕ РЕАЛИЗОВАНО. Спецификация готова, реализации нет.

---

## Цель

Создать коллективное знание общества.

---

## Предпосылки из реализованного (S86)

Сейчас есть только индивидуальная память NPC. Нет механизмов распространения знаний между NPC:

| Механизм | Статус | Примечание |
|----------|--------|------------|
| Индивидуальная память (STM + L2) | ✅ | Per-NPC, изолированная |
| NPC-NPC взаимодействие | ⚠️ | DirectiveInterpretationSubscriber — только директивы, не знания |
| Распространение слухов | ❌ | Нет механизма |
| Коллективные убеждения | ❌ | Нет сущности |
| Традиции | ❌ | Нет сущности |

---

## Новые сущности

SettlementKnowledge

FactionKnowledge

Rumor

Tradition

---

## Примеры

```text
Неурожай
↓
Голод
```

---

```text
Война
↓
Рост цен
```

---

```text
Колдун
↓
Опасность
```

---

## Новый компонент

CulturalPropagationEngine

---

## Задачи

* распространение убеждений;
* распространение слухов;
* формирование традиций;
* локальные модели мира.

---

## Поведенческий результат

Общество начинает мыслить коллективно.

---

# ЭТАП 13. PERSISTENCE

## Статус

⚠️ ЧАСТИЧНО РЕАЛИЗОВАНО. Требуется доревизия.

---

## Археологическая карта (S86)

| Компонент | Файл | Назначение |
|-----------|------|------------|
| SqlitePersistenceAdapter | `backend/app/services/persistence/sqlite_adapter.py` | Runtime truth, atomic commit |
| JsonPersistenceAdapter | `backend/app/services/persistence/json_adapter.py` | Legacy fallback (Устав §4.2.2) |
| NPCStateAdapter | `backend/app/services/npc/state_applicator.py` | from_legacy / write_to_legacy round-trip |
| atomic_commit() | `sqlite_adapter.py` | Атомарная запись scene + npc_dicts |
| persist_dm_response() | `game_loop/__init__.py:640` | Запись DM-ответа в Campaign memory |
| YAML export | `memory/yaml_export.py` | Экспорт для человека (не runtime truth) |
| JSONL startup log | `agent_runner.py` | Лог агентов (не память NPC) |

### Что сохраняется между сессиями (подтверждено S86)

| Данные | Механизм | Переживает рестарт |
|--------|----------|--------------------|
| Scene state (позиции NPC, traversals) | SQLite atomic_commit | ✅ |
| NPC dicts (body_state, affective_load, emotion) | NPCStateAdapter → SQLite | ✅ |
| STM (DialogueSession) | Только в RAM | ❌ Теряется при рестарте |
| L2 narrative_cache | NPCStateAdapter → SQLite | ✅ |
| Campaign memory | persist_dm_response() → SQLite | ✅ |
| RelationshipStore | В RAM (кэш), источник — NPC dicts | ⚠️ Частично |

### Что НЕ сохраняется (расхождение с ТЗ)

| Данные | Статус |
|--------|--------|
| ExperiencePattern | ❌ Сущность не существует |
| CausalBelief | ❌ Сущность не существует |
| IdentityTrait | ❌ Сущность не существует |
| CulturalKnowledge | ❌ Сущность не существует |
| STM при рестарте | ❌ DialogueSession только в RAM |
| yaml_export.py | ❌ ORPHAN — не импортируется нигде. Устав §4.2.2 требует YAML как export, но код не подключён |

### Критический пробел

STM (`DialogueSession`) — **только в RAM**. При перезапуске сервера текущий диалог теряется. Это нарушает непрерывность опыта NPC между сессиями, если игрок перезагружает игру в середине разговора.

---

## Требуемое состояние

Сохраняются:

* EventMemory ✅ (через L2 narrative_cache)
* ExperiencePattern ❌
* CausalBelief ❌
* IdentityTrait ❌
* CulturalKnowledge ❌

---

## Поведенческий результат

Память переживает перезапуск сервера. ⚠️ L2 и Campaign — да. STM — нет.

---

# 14. НАУЧНЫЙ ФУНДАМЕНТ: ПОДХОДЫ ДЛЯ ГЛУБОКОЙ СИМУЛЯЦИИ NPC

> **Контекст:** В маленькой деревне (5-10 NPC) глубина отыгрыша важнее количества. Каждый NPC должен быть личностью, а не функцией. Этот раздел фиксирует научные подходы, которые направляют архитектуру ENIGMA.

---

## 14.1 Agent-Based Modeling с когнитивными архитектурами ★★★★★

**Ближайший аналог:** Generative Agents (Stanford, 2023)

**Суть:** Каждый NPC — автономный агент с внутренней когнитивной архитектурой. Не скрипт, не конечный автомат, а система, которая воспринимает, запоминает, рассуждает и действует на основе своей модели мира.

**Уже реализовано в ENIGMA:**

| Компонент | Файл | Роль в когнитивной архитектуре |
|-----------|------|-------------------------------|
| PerceptualKernel | `npc_state.py` | Субъективная онтология — что NPC воспринимает и как |
| drives_base | NPC config YAML | Базовые мотивы (fear, control, significance) |
| AffectivePipeline | `affective/` | Эмоциональная обработка сигналов |
| DecisionHub | `decision_hub.py` | Утилитарное принятие решений с деформацией от эмоций |

**Что нужно усилить:**

> **Принцип: Каждый NPC имеет свою субъективную онтологию мира.**

PerceptualKernel уже определяет, что NPC видит. Но он не связан с памятью. Усиление:

```text
PerceptualKernel (что я вижу)
    + CausalBelief (как я понимаю причину)
    + ExperiencePattern (что я вынес из опыта)
    ↓
Субъективная модель мира NPC
    ↓
DecisionHub принимает решение на основе МОЕЙ модели мира, не объективной реальности
```

**Ключевой критерий:** Два NPC в одной сцене должны иметь разные модели мира. Один видит угрозу, другой — возможность. Это уже частично работает (через drives_base), но должно усиливаться через память и убеждения.

---

## 14.2 Multiplex Network Analysis (многослойные сети) ★★★★☆

**Суть:** Социальные отношения — не одно число. Это многослойная сеть, где каждый слой имеет свою логику.

**Текущее состояние:** RelationshipStore хранит trust/fear как плоские числа. Это один слой.

**Целевая архитектура:**

```text
Слой 1: Trust/Fear (эмоциональный) — РЕАЛИЗОВАНО
    "Я тебе доверяю/боюсь тебя"
    Источник: DirectiveInterpretationSubscriber, прямой опыт

Слой 2: Obligations/Contracts (Noblesse Oblige) — НЕ РЕАЛИЗОВАНО
    "Я тебе должен / ты мне должен"
    Источник: обещания, долги, клятвы

Слой 3: Belief Alignment (когнитивный) — НЕ РЕАЛИЗОВАНО
    "Мы думаем одинаково / мы расходимся"
    Источник: CausalBelief comparison

Слой 4: Memetic Influence (культурный) — НЕ РЕАЛИЗОВАНО
    "Ты влияешь на мои убеждения"
    Источник: CulturalKnowledge, слухи, традиции
```

**Зачем это нужно:**

Многослойность позволяет моделировать сложные социальные конфликты:

```text
"Я тебе доверяю (Слой 1 = высокий trust),
 но наши убеждения расходятся (Слой 3 = низкий alignment),
 и я должен тебе денег (Слой 2 = обязательство)."
```

Или:

```text
"Я тебя боюсь (Слой 1 = высокий fear),
 но мы верим в одно и то же (Слой 3 = высокий alignment),
 поэтому я подчиняюсь." (Слой 4 = меметическое влияние)
```

**Реализация:** RelationshipStore уже SSOT (ADR-121). Расширять слои через него, не создавая параллельных хранилищ.

---

## 14.3 Эпидемиологические модели (SIR для меметики) ★★★☆☆

**Суть:** Слухи, паника, идеологии распространяются как инфекция. SIR-модель (Susceptible → Infected → Recovered) применима к информации.

**Когда внедрять:** ПОСЛЕ того, как Belief Layer (Этап 10) и Cultural Knowledge (Этап 12) будут реализованы. Без убеждений нет носителей мемов.

**Архитектурный набросок:**

```text
Rumor (мем)
    ↓
NPC encounters rumor (Susceptible)
    ↓
Belief alignment check: принимает ли NPC этот мем?
    ↓ Если да → Infected (распространяет дальше)
    ↓ Если нет → Resistant (иммунитет через противоречивое убеждение)
    ↓
Со временем → Recovered (мем забывается или интегрируется в убеждение)
```

**Параметры распространения:**

| Параметр | Источник в ENIGMA |
|----------|-------------------|
| Восприимчивость | Belief Alignment (Слой 3) + PerceptualKernel.uncertainty |
| Скорость распространения | Количество социальных контактов NPC (социальная центральность) |
| Длительность "инфекции" | Importance мема + emotional charge |
| Иммунитет | Противоречивое CausalBelief (сильное убеждение блокирует мем) |

**Предупреждение:** Не реализовывать слишком рано. Без работающего Belief Layer это будет игрушка, не симуляция.

---

## 14.4 Приоритет внедрения

| Подход | Когда | Зависимость |
|--------|-------|-------------|
| Когнитивные архитектуры | Сейчас | Только связь PerceptualKernel ↔ Memory |
| Multiplex Networks | После Этапа 6 (Noblesse Oblige) | Нужен Слой 2 (обязательства) |
| SIR для меметики | После Этапа 12 (Cultural Knowledge) | Нужны убеждения как носители |

---

# КОНЕЧНЫЙ КРИТЕРИЙ ПРИЁМКИ

Если после реализации игрок может сказать:

"Этот персонаж помнит прошлое."

— система памяти ещё не закончена.

Если игрок может сказать:

"Этот персонаж сделал выводы из прошлого."

— реализован ExperiencePattern.

Если игрок может сказать:

"Этот персонаж ожидает определённое будущее."

— реализован CausalBelief.

Если игрок может сказать:

"Этот персонаж отличается от других из-за прожитой жизни."

— реализован IdentityEmergence.

Если игрок может сказать:

"В этой деревне все смотрят на мир одинаково."

— реализован CulturalKnowledge.

Только после достижения последнего уровня система может считаться завершённой.
