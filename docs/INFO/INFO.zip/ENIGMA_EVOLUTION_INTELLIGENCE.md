# ENIGMA Evolution Intelligence

## Scope
- Source: git history of version branches `origin/V.*` (42 snapshots, 2026-03-15 .. 2026-05-14).
- Constraint: no primitive LOC metrics as outputs. LOC-like values are only latent signals inside composite indexes.
- Derived dataset: `docs/INFO/enigma_evolution_metrics_derived.csv`.

## Metric Dictionary
- `EG`: Entropy Growth
- `SR`: Stabilization Ratio
- `SC`: Semantic Churn
- `GD`: Governance Density
- `CD`: Causality Depth
- `ACI`: Authority Consolidation Index
- `OER`: Ontology Expansion Rate
- `HSES`: Hidden State Elimination Score
- `RPI`: Runtime Pressure Index
- `RI`: Refactor Intensity
- `PG`: Protocolization Growth
- `SCT`: Systemic Coherence Trend (50=neutral)

## Version/Branch Intelligence Table
|Branch|Date|EG|SR|SC|GD|CD|ACI|OER|HSES|RPI|RI|PG|SCT|Trend|Phase|Unstable Domains|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|V.0.1_alfa1|2026-03-15|56.0|16.7|24.4|16.9|10.3|14.7|5.3|18.2|48.5|29.1|0.0|50.0|bootstrap|Transitional Synthesis|runtime_core|
|V.0.2_alfa1|2026-03-18|35.5|39.4|34.3|17.9|29.3|40.7|15.6|90.5|52.6|92.5|0.0|83.0|breakout_up|Refactor Compression|runtime_core|
|V.0.3A_alfa1|2026-03-19|56.6|15.7|30.5|5.0|41.7|18.7|21.0|12.0|55.9|10.9|2.7|11.2|stress_drop|Transitional Synthesis|runtime_core|
|V.0.4A_alfa2|2026-03-22|64.3|15.9|41.3|17.2|32.0|17.1|19.0|18.6|60.9|26.3|0.8|48.9|flat|Transitional Synthesis|runtime_core|
|V.0.4.2|2026-03-22|44.6|36.4|41.6|18.8|44.5|38.0|13.3|74.6|53.2|71.5|15.3|85.1|breakout_up|Refactor Compression|runtime_core|
|V.0.4.3|2026-03-28|59.9|18.3|87.6|15.6|37.0|20.1|29.6|49.3|75.0|53.8|0.0|11.6|stress_drop|Transitional Synthesis|runtime_core|
|V.0.4.4.1|2026-04-02|62.4|17.9|51.3|2.3|33.2|27.6|20.5|26.0|58.7|34.3|3.2|55.1|up|Transitional Synthesis|runtime_core, memory|
|V.0.5.0.1|2026-04-04|66.3|16.0|63.3|11.4|16.1|51.5|14.4|38.5|65.6|46.0|0.0|56.0|up|Transitional Synthesis|runtime_core, memory, authority|
|V.0.5.0.2|2026-04-07|65.6|21.4|50.9|0.0|42.6|19.6|32.8|13.7|53.6|21.7|6.8|41.4|down|Transitional Synthesis|runtime_core, memory|
|V.0.5.0.3|2026-04-07|71.6|19.5|25.7|5.0|55.7|7.6|19.3|5.4|53.8|10.9|5.6|48.3|flat|Entropy Surge|spatial, runtime_core|
|V.0.5.0.4|2026-04-09|55.0|33.0|74.4|28.1|35.7|36.7|28.5|62.9|60.9|72.0|4.1|73.4|breakout_up|Refactor Compression|runtime_core|
|V.0.5.0.5|2026-04-10|41.0|36.6|41.3|24.6|10.1|30.2|7.6|63.3|46.8|72.1|1.5|60.0|breakout_up|Refactor Compression|runtime_core|
|V.0.5.0.6|2026-04-11|64.8|23.4|54.4|7.5|12.9|33.7|15.4|31.9|52.8|41.3|4.3|28.3|stress_drop|Transitional Synthesis|runtime_core, presentation|
|V.0.5.0.7|2026-04-12|71.4|21.1|50.1|12.3|33.5|20.1|31.2|14.9|59.1|22.5|16.6|43.1|down|Entropy Surge|runtime_core, presentation|
|V.0.5.0.8|2026-04-15|75.4|19.6|61.0|9.9|23.8|23.4|33.8|17.4|58.2|24.0|7.7|46.1|down|Entropy Surge|runtime_core, spatial|
|V.0.5.0.9|2026-04-19|53.9|6.0|54.7|0.3|8.8|12.3|40.1|4.7|58.0|12.8|1.4|39.5|stress_drop|Transitional Synthesis|spatial|
|V.0.5.1.0_Починил_ллм|2026-04-22|67.5|19.9|70.2|5.0|41.0|31.0|28.7|31.0|65.9|40.2|9.3|62.6|breakout_up|Transitional Synthesis|runtime_core, presentation|
|V.0.5.1.1_Встроил_ТИК_ТАК|2026-04-23|58.9|13.8|27.3|7.3|11.5|19.4|7.6|12.4|52.4|21.4|1.5|51.5|flat|Transitional Synthesis|runtime_core, memory|
|V.0.5.1.2_Встроил_ПАМЯТЬ_0.1и0.2|2026-04-25|60.1|8.5|36.4|2.3|13.3|26.1|12.6|18.2|58.8|25.0|0.0|46.3|down|Transitional Synthesis|runtime_core|
|V.0.5.1.3_Встроил_Кратковременную_память|2026-04-25|56.7|11.3|31.6|3.1|10.9|21.4|9.1|16.7|56.4|26.1|6.3|52.9|up|Transitional Synthesis|runtime_core, memory|
|V.0.5.1.4_Начал_чинить_GAME_LOOP|2026-04-26|66.9|30.4|45.0|57.5|33.0|11.0|37.1|11.9|55.7|19.0|13.1|62.9|breakout_up|Transitional Synthesis|runtime_core|
|V.0.5.1.5_Продолжаю_починку_игры|2026-04-26|78.0|28.6|92.8|44.3|31.4|25.6|46.0|49.6|73.9|43.5|23.4|46.3|down|Entropy Surge|runtime_core, presentation|
|V.0.5.1.6_Продолжаю_починку_2|2026-04-28|52.3|28.7|65.7|16.5|12.1|32.1|9.5|50.4|54.3|59.6|8.3|56.5|up|Transitional Synthesis|runtime_core, spatial|
|V.0.5.1.7_Продолжаю_починку_3|2026-04-28|55.6|22.2|53.1|20.5|13.7|33.4|5.6|42.0|56.7|50.2|0.0|46.2|down|Transitional Synthesis|runtime_core|
|V.0.5.1.8_Продолжаю_починку_4|2026-04-30|70.3|16.4|60.8|10.5|46.1|19.4|35.3|28.6|70.2|34.9|11.5|33.7|stress_drop|Entropy Surge|runtime_core, spatial, temporal|
|V.0.5.1.9_Продолжаю_починку_5|2026-04-30|64.3|24.5|46.7|0.0|14.7|18.7|25.5|30.0|56.4|35.5|30.0|62.1|breakout_up|Transitional Synthesis|runtime_core, spatial, memory|
|V.0.5.2.0_Починил_запуск_игры|2026-05-01|71.0|23.2|56.7|16.4|34.0|19.6|22.7|30.9|62.8|36.9|17.7|46.4|down|Entropy Surge|runtime_core, memory, spatial|
|V.0.5.2.1_Пора_сломать_DecisionHub|2026-05-01|20.8|22.7|36.3|5.8|5.0|34.7|8.5|33.5|45.1|41.0|0.4|64.6|breakout_up|Transitional Synthesis|presentation|
|V.0.5.2.2_Почти_почти|2026-05-02|64.7|19.9|67.3|8.3|53.0|31.8|26.7|39.4|73.1|47.5|18.3|34.2|stress_drop|Transitional Synthesis|runtime_core, temporal, spatial|
|V.0.5.2.3_Почти_почти_2|2026-05-02|70.2|18.7|81.6|7.8|50.2|23.0|20.8|43.6|75.4|49.0|7.3|41.3|down|Entropy Surge|runtime_core, temporal, presentation|
|V.0.5.2.4_Почти_почти_3|2026-05-03|71.7|24.8|72.4|28.2|50.6|28.0|23.0|40.2|72.1|46.7|15.9|61.9|breakout_up|Entropy Surge|runtime_core, spatial, temporal|
|V.0.5.2.5_Почти_почти_4|2026-05-04|61.0|25.0|79.5|18.0|58.0|33.4|20.4|53.8|73.1|60.3|13.6|52.0|flat|Transitional Synthesis|runtime_core, spatial, temporal|
|V.0.5.2.6_Почти_почти_5|2026-05-05|60.6|38.2|49.8|39.5|39.4|27.2|16.0|35.4|48.7|41.1|13.5|65.8|breakout_up|Transitional Synthesis|runtime_core, spatial|
|V.0.5.2.7_Почти_почти_6|2026-05-06|47.6|51.5|51.9|39.6|41.8|32.9|11.2|60.6|38.8|69.3|22.6|68.7|breakout_up|Refactor Compression|none|
|V.0.5.2.8_Почти_почти_7|2026-05-07|67.9|26.6|42.6|30.5|56.8|17.9|23.4|20.6|59.4|26.3|15.8|16.7|stress_drop|Transitional Synthesis|runtime_core, presentation, spatial|
|V.0.5.2.9_СМЕНИЛ_подход|2026-05-08|65.7|32.0|45.0|36.0|62.5|32.2|29.5|27.7|59.5|34.8|29.6|62.1|breakout_up|Transitional Synthesis|runtime_core, spatial, temporal|
|V.0.5.3.0.1_НОВАЯ_РЕАЛЬНОСТЬ_1|2026-05-10|71.7|22.7|51.2|18.6|54.7|17.2|32.1|21.5|64.8|28.7|20.8|31.3|stress_drop|Entropy Surge|runtime_core, presentation|
|V.0.5.3.0.2_НОВАЯ_РЕАЛЬНОСТЬ_2|2026-05-11|71.9|27.0|77.1|35.7|62.0|30.7|24.4|43.9|72.8|52.9|27.9|59.3|breakout_up|Entropy Surge|causal, runtime_core, ontology|
|V.0.5.3.0.3_НОВАЯ_РЕАЛЬНОСТЬ_3|2026-05-12|72.4|26.3|65.5|13.5|65.0|14.3|43.3|23.1|63.5|29.3|22.2|38.4|stress_drop|Entropy Surge|runtime_core, presentation|
|V.0.5.3.0.4_ПЕСОЧНИЦЫ_1|2026-05-12|65.6|43.5|35.6|56.1|67.8|10.8|20.3|19.6|45.1|19.3|15.5|74.0|breakout_up|Transitional Synthesis|none|
|V.0.5.3.0.5_ПЕСОЧНИЦЫ_2|2026-05-14|65.2|35.8|55.5|57.5|65.0|21.9|32.4|31.9|62.8|37.1|26.1|47.6|down|Causal Stress Integration|runtime_core, causal|
|V.0.5.3.0.6_ПЕСОЧНИЦЫ_3|2026-05-14|68.6|38.3|57.0|75.6|66.4|16.7|26.9|27.1|54.8|32.1|5.5|49.1|flat|Entropy Surge|spatial, runtime_core|
|V.0.5.3.0.7_ПЕСОЧНИЦЫ_4|2026-05-16|63.4|41.7|44.2|81.3|72.8|38.4|35.7|46.2|58.9|33.8|31.5|71.4|breakout_up|Causal Governance Consolidation|directive_authority, spatial, initiative|
|V.0.5.3.0.8_ПЕСОЧНИЦЫ_5|2026-05-17|59.8|48.9|39.5|88.6|78.1|57.2|42.6|63.8|52.7|29.4|44.8|83.7|breakout_up|Distributed Social Physics|initiative, social_pressure, locomotion|

## Extended Metric Interpretation (post-ADR-048/049/050)

- `EG` — больше не просто “хаос изменений”, а степень расширения причинного пространства.
- `SR` — устойчивость causal-loop после интеграции новых pressure domains.
- `SC` — интенсивность перестройки смысловой геометрии runtime.
- `GD` — плотность enforceable contracts между фазами/доменами.
- `CD` — глубина многослойной причинности (decision → pressure → spatial → projection).
- `ACI` — степень консолидации authority-spines (`SpatialQueryService`, directive legitimacy, orchestration law).
- `OER` — скорость расширения онтологии симуляции без collapse в script-layer.
- `HSES` — устранение скрытых truth-sources и bypass-состояний.
- `RPI` — суммарное давление runtime на устойчивость causal execution.
- `RI` — интенсивность хирургии архитектуры.
- `PG` — перевод implicit behavior в formalized protocols/contracts.
- `SCT` — долгосрочная когерентность distributed causality.

## New Phase Definitions

|Phase|Meaning|
|---|---|
|Distributed Social Physics|Социальное давление начинает существовать как causal field, а не как dialogue logic.|
|Causal Governance Consolidation|Власть и легитимность переходят из “поведения NPC” в enforceable runtime geometry.|
|Embodied Causality Threshold|Movement, hesitation, suppression и perception начинают сливаться в единую embodied cognition систему.|
|Civilization Pressure Runtime|Мир хранит не события, а остаточные градиенты нерешённого давления.|

## Emerging System Trajectory (May 2026+)

```text
Phase I:
Stateful Runtime
↓
Phase II:
Causal Orchestrator
↓
Phase III:
Observed Reality Simulation
↓
Phase IV:
Distributed Social Physics
↓
Phase V:
Civilization Pressure Runtime
↓
Phase VI:
Mythogenic Causal Ecology

## Branch-Family Trends
|Branch Family|N|EG avg|SR avg|RPI avg|PG avg|Delta Coherence|Phase End|
|---|---:|---:|---:|---:|---:|---:|---|
|V.0.1|1|56.0|16.7|48.5|0.0|0.0|Transitional Synthesis|
|V.0.2|1|35.5|39.4|52.6|0.0|0.0|Refactor Compression|
|V.0.3|1|56.6|15.7|55.9|2.7|0.0|Transitional Synthesis|
|V.0.4|1|64.3|15.9|60.9|0.8|0.0|Transitional Synthesis|
|V.0.4.2|1|44.6|36.4|53.2|15.3|0.0|Refactor Compression|
|V.0.4.3|1|59.9|18.3|75.0|0.0|0.0|Transitional Synthesis|
|V.0.4.4|1|62.4|17.9|58.7|3.2|0.0|Transitional Synthesis|
|V.0.5.0|9|62.8|21.8|56.5|5.3|-13.2|Transitional Synthesis|
|V.0.5.1|10|63.1|20.4|60.1|10.3|5.8|Transitional Synthesis|
|V.0.5.2|10|60.1|28.3|60.8|15.5|11.5|Transitional Synthesis|
|V.0.5.3|6|69.2|32.3|60.6|19.7|12.3|Entropy Surge|

## Causal Link Candidates (lag t-1 -> t)
- Reported when abs(correlation) >= 0.38. This is lag-based causal evidence, not strict causal proof.
- `governance_density` +> `stabilization_ratio`: r=0.50
- `causality_depth` +> `governance_density`: r=0.48
- `protocolization_growth` +> `governance_density`: r=0.42
- `governance_density` +> `systemic_coherence_score`: r=0.40
- `causality_depth` +> `stabilization_ratio`: r=0.40
- `stabilization_ratio` +> `governance_density`: r=0.40
- `protocolization_growth` +> `causality_depth`: r=0.38

## Architectural Phase Distribution
- `Transitional Synthesis`: 24 versions (V.0.1_alfa1 -> V.0.5.3.0.4_ПЕСОЧНИЦЫ_1)
- `Entropy Surge`: 12 versions (V.0.5.0.3 -> V.0.5.3.0.6_ПЕСОЧНИЦЫ_3)
- `Refactor Compression`: 5 versions (V.0.2_alfa1 -> V.0.5.2.7_Почти_почти_6)
- `Causal Stress Integration`: 1 versions (V.0.5.3.0.5_ПЕСОЧНИЦЫ_2 -> V.0.5.3.0.5_ПЕСОЧНИЦЫ_2)

## Unstable Domain Ranking
|Domain|Instability Weight|
|---|---:|
|runtime_core|9.042|
|spatial|2.272|
|presentation|1.922|
|memory|1.272|
|temporal|1.189|
|causal|0.688|
|authority|0.650|
|ontology|0.516|

## Coherence Breakpoints
- Top coherence lifts: `V.0.4.2` (2026-03-22) delta=23.43; `V.0.2_alfa1` (2026-03-18) delta=21.99; `V.0.5.3.0.4_ПЕСОЧНИЦЫ_1` (2026-05-12) delta=16.01; `V.0.5.0.4` (2026-04-09) delta=15.59.
- Top coherence drops: `V.0.3A_alfa1` (2026-03-19) delta=-25.84; `V.0.4.3` (2026-03-28) delta=-25.63; `V.0.5.2.8_Почти_почти_7` (2026-05-07) delta=-22.22; `V.0.5.0.6` (2026-04-11) delta=-14.44.

---

## Current Branch: V.0.5.3.0.7_ПЕСОЧНИЦЫ_8
- Date: 2026-05-17
- Focus: integration of affective pressure, decision-context geometry, authoritative spatial query contracts, and The Fool as a living validation scenario.
- Value note: the current branch prioritizes causal traceability, enforcement, and sandbox observability over raw line growth.
- The future implied by `docs/Tasks` and `docs/audits`: keep `The Fool` as the system-level design lens where game logic is expressed through contracts and causal pipelines.

---

## Notes on future orientation
- `docs/Tasks` are the action plan; they encode the next practical steps for ENIGMA.
- `docs/audits` are the governance layer; they define what must be reviewed, audited, and preserved.
- Together they form the future roadmap of The Fool as a distributed reality simulation.
