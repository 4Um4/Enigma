# -*- coding: utf-8 -*-
"""
ReactionPriority — кто из NPC реагирует на событие и в каком порядке.
backend/app/services/npc/reaction_priority.py

Фаза S.4.2

Принцип: Python решает КТО, КОГДА и ПОЧЕМУ реагирует.
LLM только озвучивает. Никакого хардкода имён — только роли из id-префикса
и драйвы из JSON. Новый NPC с role="guard" работает автоматически.

Публичный API для orchestrator:
    get_reaction_order(npcs, scene_state, scene_changes) -> list[dict]
    Возвращает список NPC отсортированный по приоритету (высший первый).
    Только те у кого score >= THRESHOLD_WILL_REACT.
"""

from __future__ import annotations
from typing import Any
import logging

logger = logging.getLogger(__name__)

# Импорт SceneChange — если недоступен, модуль деградирует gracefully
try:
    from app.services.scene_change import SceneChange, ChangeType
    _SCENE_CHANGE_AVAILABLE = True
except ImportError:
    SceneChange = None   # type: ignore
    ChangeType  = None   # type: ignore
    _SCENE_CHANGE_AVAILABLE = False


# ──────────────────────────────────────────────────────────────────────────────
# 1. Пороги приоритета
# ──────────────────────────────────────────────────────────────────────────────

THRESHOLD_MUST_REACT  = 60   # NPC обязан вмешаться — он не может промолчать
THRESHOLD_WILL_REACT  = 30   # NPC реагирует — перебивает или встаёт
THRESHOLD_MAY_REACT   = 15   # NPC замечает — меняет позу, смотрит

# Максимум NPC которые получают слово за один ход (чтобы не было свалки)
MAX_SPEAKERS_PER_TURN = 3


# ──────────────────────────────────────────────────────────────────────────────
# 2. Таблица обязанностей по роли
#    Роль определяется по префиксу npc["id"] — без хардкода конкретных имён.
#    Добавить новую роль = добавить строку в словарь.
# ──────────────────────────────────────────────────────────────────────────────

# Формат: "префикс_id" -> {триггер_события -> бонус_к_score}
_DUTY_TABLE: dict[str, dict[str, int]] = {
    "tavern_keeper": {"stop_theft": 70, "stop_violence": 65, "protect_worker": 75},
    "innkeeper":     {"stop_theft": 70, "stop_violence": 65, "protect_worker": 75},
    "guard":         {"stop_theft": 85, "stop_violence": 85, "stop_disorder": 70},
    "merchant":      {"stop_theft": 80, "protect_goods": 80},
    "priest":        {"stop_violence": 55, "heal_wounded": 65},
    "maid":          {"stop_violence": 20},
    "barmaid":       {"stop_violence": 20},
    "soldier":       {"stop_violence": 75, "stop_disorder": 60},
    "bandit":        {"join_violence": 40, "stop_theft": -20},   # бандит не против драки
}


# ──────────────────────────────────────────────────────────────────────────────
# 3. Анализ SceneChange — какое событие произошло
#    Все функции принимают change: SceneChange и возвращают bool.
#    Добавить новый тип события = добавить функцию по этому паттерну.
# ──────────────────────────────────────────────────────────────────────────────

def _is_violence(change: Any) -> bool:
    """Физическое насилие над NPC или игроком."""
    if not _SCENE_CHANGE_AVAILABLE:
        return False
    if change.type == ChangeType.NPC_STATE:
        return change.field in ("hp", "psyche_state") or change.value in (
            "dead", "unconscious", "broken", "wounded"
        )
    if change.type == ChangeType.OBJECT_STATE and change.cause in (
        "player_attack", "combat", "player_improvised_weapon"
    ):
        return True
    return False


def _is_theft(change: Any) -> bool:
    """Кража объекта или золота."""
    if not _SCENE_CHANGE_AVAILABLE:
        return False
    if change.type == ChangeType.OBJECT_REMOVE and "steal" in change.cause:
        return True
    if change.type == ChangeType.INVENTORY and "steal" in change.cause:
        return True
    if change.type == ChangeType.INVENTORY and "pickpocket" in change.cause:
        return True
    return False


def _is_disorder(change: Any) -> bool:
    """Нарушение порядка — шум, поломка, вторжение."""
    if not _SCENE_CHANGE_AVAILABLE:
        return False
    if change.type == ChangeType.OBJECT_STATE and change.value in (
        "damaged", "broken", "burning"
    ):
        return True
    if change.type == ChangeType.ENVIRONMENT:
        return change.field in ("noise_level", "fire", "smoke")
    if change.type == ChangeType.EFFECT_ADD and isinstance(change.value, dict):
        return change.value.get("type") in ("fire", "smoke", "alarm")
    return False


def _is_disrespect(change: Any) -> bool:
    """Неуважение к NPC — провокация, запугивание, оскорбление."""
    if not _SCENE_CHANGE_AVAILABLE:
        return False
    return change.cause in ("player_taunt", "player_intimidate") or (
        change.type == ChangeType.NPC_STATE and
        change.field == "mood" and
        change.value in ("aggravated", "humiliated", "fearful")
    )


def _is_danger(change: Any) -> bool:
    """Опасность в локации — огонь, отравление, угроза."""
    if not _SCENE_CHANGE_AVAILABLE:
        return False
    if change.type == ChangeType.EFFECT_ADD and isinstance(change.value, dict):
        return change.value.get("type") in ("fire", "poisoned", "cursed", "trapped")
    return _is_violence(change)


def _is_opportunity(change: Any) -> bool:
    """Возможность для NPC — упавшее золото, беспомощная жертва."""
    if not _SCENE_CHANGE_AVAILABLE:
        return False
    if change.type == ChangeType.INVENTORY and change.field == "add":
        val = change.value or {}
        return "gold" in val
    return False


def _classify_change(change: Any) -> set[str]:
    """
    Возвращает набор тегов события для сопоставления с _DUTY_TABLE.
    Один SceneChange может иметь несколько тегов.
    """
    tags: set[str] = set()
    if _is_violence(change):
        tags.add("stop_violence")
    if _is_theft(change):
        tags.add("stop_theft")
        tags.add("protect_goods")
    if _is_disorder(change):
        tags.add("stop_disorder")
    if _is_disrespect(change):
        tags.add("stop_disrespect")
    if _is_danger(change):
        tags.add("heal_wounded")
    return tags


# ──────────────────────────────────────────────────────────────────────────────
# 4. Анализ NPC — кто он и как связан с событием
# ──────────────────────────────────────────────────────────────────────────────

def _get_role(npc: dict) -> str:
    """
    Определяет роль NPC по префиксу его id.
    npc["id"] = "tavern_keeper_tornin" → роль "tavern_keeper"
    npc["id"] = "guard_north"          → роль "guard"
    Без хардкода конкретных имён.
    """
    npc_id = npc.get("id", "")
    for role in _DUTY_TABLE:
        if npc_id.startswith(role):
            return role
    return "unknown"


def _directly_affects_npc(npc: dict, change: Any) -> bool:
    """Событие напрямую касается этого NPC (target == npc.id)."""
    if not _SCENE_CHANGE_AVAILABLE:
        return False
    return change.target == npc.get("id")


def _affects_related_npc(npc: dict, change: Any, all_npcs: list[dict]) -> bool:
    """
    Событие касается NPC с которым у данного NPC есть значимая связь
    (из поля relationships, значение >= 50 = важный союзник).
    """
    relationships = npc.get("relationships", {})
    target_id = change.target if _SCENE_CHANGE_AVAILABLE else ""
    score = relationships.get(target_id, 0)
    return score >= 50


def _get_distance(npc: dict, scene_state: dict) -> float:
    """
    Расстояние от NPC до игрока в метрах из SceneState.
    Если нет данных — возвращает 5.0 (нейтральное).
    """
    distances = scene_state.get("player_distances", {})
    npc_id = npc.get("id", "")
    return float(distances.get(npc_id, 5.0))


def _get_psyche_modifier(npc: dict) -> int:
    """
    Модификатор от психологического состояния NPC.
    Сломленный или сверхстрессовый NPC реагирует хуже.
    """
    psyche = npc.get("psyche", {})
    state  = psyche.get("state", "free")
    stress = psyche.get("stress", 0)

    modifier = 0
    if state == "broken":
        modifier -= 35   # сломлен — боится вмешиваться
    elif state == "coerced":
        modifier -= 15   # принуждён — осторожен
    elif state == "loyal":
        modifier += 15   # предан — активнее защищает

    if stress > 80:
        modifier -= 15   # высокий стресс снижает инициативу
    elif stress < 20:
        modifier += 5    # спокойный NPC реагирует увереннее

    return modifier


# ──────────────────────────────────────────────────────────────────────────────
# 5. Расчёт score для одного NPC относительно одного SceneChange
# ──────────────────────────────────────────────────────────────────────────────

def _calculate_single(npc: dict, scene_state: dict, change: Any,
                       all_npcs: list[dict]) -> int:
    """
    Считает приоритет реакции одного NPC на одно изменение SceneState.
    Возвращает int 0–100+.
    Вызывается из calculate_reaction_scores() для каждой пары (npc, change).
    """
    score = 0

    # ── Прямое воздействие ────────────────────────────────────────────────────
    if _directly_affects_npc(npc, change):
        score += 80   # событие случилось с самим NPC — он точно реагирует

    # ── Связь с пострадавшим ──────────────────────────────────────────────────
    if _affects_related_npc(npc, change, all_npcs):
        score += 50   # союзник пострадал

    # ── Обязанности по роли ───────────────────────────────────────────────────
    role = _get_role(npc)
    change_tags = _classify_change(change)
    duties = _DUTY_TABLE.get(role, {})
    for tag in change_tags:
        bonus = duties.get(tag, 0)
        score += bonus   # может быть отрицательным (бандит не против кражи)

    # ── Драйвы NPC ────────────────────────────────────────────────────────────
    drives = npc.get("drives", {})
    if drives.get("control", 0) >= 0.5 and _is_disorder(change):
        score += 30   # любит контроль — не терпит беспорядка
    if drives.get("significance", 0) >= 0.5 and _is_disrespect(change):
        score += 25   # любит уважение — оскорбление задевает
    if drives.get("fear", 0) >= 0.5 and _is_danger(change):
        score += 20   # тревожный NPC заметит опасность раньше
    if drives.get("desire", 0) >= 0.6 and _is_opportunity(change):
        score += 20   # жадный заметит возможность

    # ── Расстояние ────────────────────────────────────────────────────────────
    distance = _get_distance(npc, scene_state)
    distance_penalty = int(distance * 4)   # каждый метр = -4 к score
    score -= distance_penalty

    # ── Видимость ─────────────────────────────────────────────────────────────
    npc_id  = npc.get("id", "")
    npc_pos = scene_state.get("npc_positions", {}).get(npc_id, {})
    if not npc_pos.get("visible", True):
        score -= 25   # NPC не видит что происходит (спрятан, за стеной)

    # ── Психологическое состояние ─────────────────────────────────────────────
    score += _get_psyche_modifier(npc)

    return max(0, score)


# ──────────────────────────────────────────────────────────────────────────────
# 6. Публичный API — вызывается из orchestrator
# ──────────────────────────────────────────────────────────────────────────────

def get_reaction_order(
    npcs: list[dict],
    scene_state: dict,
    scene_changes: list,
) -> list[dict]:
    """
    Главная функция модуля. Вызывается из orchestrator после SandboxHandler.

    Принимает:
        npcs          — список NPC в локации (из _get_npcs_in_location)
        scene_state   — текущий SceneState
        scene_changes — список SceneChange из SandboxResult

    Возвращает:
        Список dict отсортированный по score (высший первый).
        Только NPC с score >= THRESHOLD_WILL_REACT.
        Максимум MAX_SPEAKERS_PER_TURN записей.

        Формат каждого элемента:
        {
            "npc_id":    str,
            "npc_name":  str,
            "score":     int,
            "threshold": "must_react" | "will_react" | "may_react",
            "triggers":  list[str],   # теги событий которые сработали
        }
    """
    if not npcs or not scene_changes:
        return []

    # Агрегируем score по всем изменениям — NPC реагирует на самое сильное
    npc_scores: dict[str, int] = {}
    npc_triggers: dict[str, set[str]] = {}

    for change in scene_changes:
        if not _SCENE_CHANGE_AVAILABLE or not isinstance(change, SceneChange):
            continue
        change_tags = _classify_change(change)

        for npc in npcs:
            npc_id = npc.get("id", "")
            if not npc_id:
                continue

            single_score = _calculate_single(npc, scene_state, change, npcs)

            # Берём максимум по всем SceneChange за ход
            current = npc_scores.get(npc_id, 0)
            if single_score > current:
                npc_scores[npc_id] = single_score
                npc_triggers[npc_id] = change_tags

    # Фильтруем по порогу и сортируем
    results = []
    npc_by_id = {n.get("id"): n for n in npcs}

    for npc_id, score in npc_scores.items():
        if score < THRESHOLD_WILL_REACT:
            continue

        npc = npc_by_id.get(npc_id, {})
        if score >= THRESHOLD_MUST_REACT:
            threshold_label = "must_react"
        elif score >= THRESHOLD_WILL_REACT:
            threshold_label = "will_react"
        else:
            threshold_label = "may_react"

        results.append({
            "npc_id":    npc_id,
            "npc_name":  npc.get("name", npc_id),
            "score":     score,
            "threshold": threshold_label,
            "triggers":  sorted(npc_triggers.get(npc_id, set())),
        })

    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:MAX_SPEAKERS_PER_TURN]